export SEYREN_LOG_PATH=./
java -jar seyren-1.3.0.jar > seyren.out 2>&1 &
