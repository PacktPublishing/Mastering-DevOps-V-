sudo cp graphite.conf /etc/apache2/sites-available
sudo apachectl restart
