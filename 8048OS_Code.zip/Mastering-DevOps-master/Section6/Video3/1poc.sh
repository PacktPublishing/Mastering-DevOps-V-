echo mastering.devops.section.6 3 `date +%s` | nc -w 3 localhost 22003
